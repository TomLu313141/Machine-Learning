#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt

linewidths = [0.5, 1.0, 2.0, 4.0]
linestyles = ['-', '--', '-.', ':']
markers = ['+', 'o', '*', 's', '.', '1', '2', '3', '4'] 
markersizecolors = [(4, "white"), (8, "red"), (12, "yellow"), (16, "lightgreen")]


# In[2]:


x = np.linspace(-5, 5, 5)
y = np.ones_like(x)
def axes_settings(fig, ax, title, ymax):
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_ylim(0, ymax+1)
    ax.set_title(title)
    
fig, axes = plt.subplots(1, 4, figsize=(16,3))
# Line width
linewidths = [0.5, 1.0, 2.0, 4.0]
for n, linewidth in enumerate(linewidths):
    
    # pic 1
    axes[0].plot(x, y + n, color="blue", linewidth=linewidth) 
    axes_settings(fig, axes[0], "linewidth", len(linewidths))
    
# pic2
axes[1].plot(x, y, color="blue", linestyle="-") 
axes[1].plot(x, y + 1, color="blue", linestyle="--") 
axes[1].plot(x, y + 2, color="blue", linestyle="-.") 
axes[1].plot(x, y + 3, color="blue", linestyle=":") 

axes_settings(fig, axes[1], "linetypes", len(linewidths))

    
# pic 3
axes[2].plot(x, y - 0.5, color="blue", linewidth=0, marker="+")
axes[2].plot(x, y, color="blue", linewidth=0, marker="o") 
axes[2].plot(x, y + 0.5, color="blue", linewidth=0, marker="*") 
axes[2].plot(x, y + 1.0, color="blue", linewidth=0, marker="s") 
axes[2].plot(x, y + 1.5, color="blue", linewidth=0, marker=".") 
axes[2].plot(x, y + 2.0, color="blue", linewidth=0, marker="1") 
axes[2].plot(x, y + 2.5, color="blue", linewidth=0, marker="2") 
axes[2].plot(x, y + 3.0, color="blue", linewidth=0, marker="3") 
axes[2].plot(x, y + 3.5, color="blue", linewidth=0, marker="4") 

axes_settings(fig, axes[2], "markers", len(linewidths))
    
# pic 4
axes[3].plot(x, y, color="blue", linewidth=0, marker="o", markerfacecolor='blue', markersize=4) 
axes[3].plot(x, y + 1, color="blue", linewidth=0, marker="o", markerfacecolor='red', markersize=8) 
axes[3].plot(x, y + 2, color="blue", linewidth=0, marker="o", markerfacecolor='yellow', markersize=12) 
axes[3].plot(x, y + 3, color="blue", linewidth=0, marker="o", markerfacecolor='lightgreen', markersize=16) 

axes_settings(fig, axes[3], "marker size/color", len(linewidths))


# In[ ]:




