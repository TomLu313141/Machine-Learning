#!/usr/bin/env python
# coding: utf-8

# In[8]:


import numpy as np
import matplotlib.pyplot as plt

def least_squares_fit(x, y):
    
    avg_x = 0.
    avg_y = 0.
    
    for i in range(0,4):
        avg_x += X[i]
        avg_y += Y[i]
        
        
    avg_x /= len(X)
    avg_y /= len(Y)

    
    molecular = 0.
    denominator = 0.
    
    for i in range(0,4):
        molecular += (X[i] - avg_x) * (Y[i] - avg_y)
        denominator += (X[i] - avg_x) * (X[i] - avg_x)
        
    beta1 = molecular/denominator
    beta0 = avg_y - beta1*avg_x
    
    return beta0, beta1
    
X = np.array([1,2,3,4])
Y = np.array([9,13,14,18])

beta0, beta1 = least_squares_fit(X,Y)
least_squares_fit(X,Y)

print("From home-made linear regression model")
print('beta0 =', beta0)
print('beta1 =', beta1)

# y = beta0 + beta1*x
y = beta0 + beta1*X

plt.scatter(X, Y) # 繪製散佈圖
plt.plot(X, y, color="red", linewidth=3, markersize=30) # 繪製x,y軸的圖

plt.show() # 顯現圖形


# In[ ]:




