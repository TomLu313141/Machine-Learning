#!/usr/bin/env python
# coding: utf-8

# In[1]:


import math

def sin(x):

    y = x
    
    for i in range(2,26):
        if (i%2) == 0:
            y -= (x**(2*i - 1))/math.factorial((2*i - 1))
        else:
            y += (x**(2*i - 1))/math.factorial((2*i - 1))
          
    return y

sin(1.6)


# In[ ]:




